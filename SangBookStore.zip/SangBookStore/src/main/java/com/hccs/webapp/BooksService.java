package com.hccs.webapp;

import java.util.ArrayList;

public interface BooksService {
	
	public ArrayList<Books> getBooksList();
	
}
