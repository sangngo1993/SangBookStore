package com.hccs.webapp;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class BooksServiceImpl implements BooksService {

	@Autowired
	private BooksDAO bookDAO;
	
	public BooksServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	@Transactional
	public ArrayList<Books> getBooksList() {
		return bookDAO.getBooksList();
	}
	
	

}
