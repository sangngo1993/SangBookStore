package com.hccs.webapp;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping
public class BooksController {

	@Autowired
	private BooksService booksService;
	
	public BooksController() {
		// TODO Auto-generated constructor stub
	}
	@RequestMapping(value="/bookslist", method= RequestMethod.GET)
	public ModelAndView getBooksList(ModelAndView model) {
		ArrayList<Books> booksList = booksService.getBooksList();
		model.addObject("booksList",booksList);
		model.setViewName("bookslist");
		return model;
	}
	
	
}
