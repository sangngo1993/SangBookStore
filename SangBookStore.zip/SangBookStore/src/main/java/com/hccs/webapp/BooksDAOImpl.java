package com.hccs.webapp;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.hibernate.SessionFactory;

@Repository
public class BooksDAOImpl implements BooksDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public BooksDAOImpl() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public ArrayList<Books> getBooksList() {
		ArrayList<Books> booksList = 
				(ArrayList<Books>)sessionFactory.
				getCurrentSession().createQuery("FROM Books").
				list();
		return booksList;
	}

}
