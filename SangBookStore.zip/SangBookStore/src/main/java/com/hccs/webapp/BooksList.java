package com.hccs.webapp;

import java.util.ArrayList;

public class BooksList {

	private static ArrayList<Books> booksList;
	
	public static void setStudentsList(ArrayList<Books> booksList) {
		booksList = booksList;
	}
}
