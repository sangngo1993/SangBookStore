package com.hccs.webapp;

import java.util.ArrayList;

public interface BooksDAO {
	
	public ArrayList<Books> getBooksList();

}
