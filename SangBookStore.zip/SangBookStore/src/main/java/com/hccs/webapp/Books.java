package com.hccs.webapp;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BOOKS")
public class Books implements Serializable {

	@Id
	@Column(name="BooksID")
	private int id;
	@Column(name="Title")
	private String title;
	@Column(name="Author")
	private String author;
	@Column(name="Price")
	private float price;
	@Column(name="Quantity")
	private int quantity;
	@Column(name="ImagePath")
	private String image;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public String getimage() {
		return image;
	}

	public void setimage(String image) {
		this.image = image;
	}

	public Books() {
		// TODO Auto-generated constructor stub
	}
	
	public Books(int id, String title, String author) {
		setId(id);
		setTitle(title);
		setAuthor(author);		
	}

	@Override
	public String toString() {
		return "Books [id=" + id + ", Title=" + title + ", Author=" + author + ", Price=" + price + ", Quantity="
				+ quantity + "Image URL: " + image + "]";
	}
	
	

}
