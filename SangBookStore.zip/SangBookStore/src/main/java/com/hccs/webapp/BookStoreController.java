package com.hccs.webapp;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/")
public class BookStoreController {

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String viewStudentDetails(ModelMap model) {
	    return "home";
	}
	
	@RequestMapping(value = "/signup", method = RequestMethod.GET)
	public String viewStudentDetails2(ModelMap model) {
	    return "signup";
	}
	
	@RequestMapping(value = "/blog", method = RequestMethod.GET)
	public String viewBlogDetails(ModelMap model) {
	    return "blog";
	}
	
	@RequestMapping(value = "/about", method = RequestMethod.GET)
	public String viewAboutDetails(ModelMap model) {
	    return "about";
	}
	
	
}